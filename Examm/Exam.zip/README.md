1. What is your COVID-19 web app name?<br>
CARE-VID<br>
2. What is your motivation?<br>
To pass the requirements of the exam and to have fun in designing and exploring the bootstrap.<br>
3. Link to your Sitemap, Wireframe, and Video Pitch<br>
https://classroom.google.com/u/0/c/MTIxODUxMTA4MjYx/a/MTI2NzMwMzU2ODk3/details<br>
https://classroom.google.com/u/0/c/MTIxODUxMTA4MjYx/a/MTI2NzI2ODY0MTMx/details<br>
https://drive.google.com/file/d/15r2rWCE1ca73jYZUuQMWn1pd4pJFVQss/view?usp=sharing<br>
4. What are the web tools you used to create your web app?<br>
I used Github, codepen, W3school,Visual Studio Code and google for references.<br>
5. Discuss what you learned in this (a) COVID-19 web app project and (b) Web Development 1 Course/Subject. <br> 
I learned how to use bootstrap which makes my work faster especially if the given time for the project was limited or short.<br>
I've learn the basic concepts to a more complicated ones, from a scratch web making to a more easier one using bootstrap.<br>
6. What is something you need to improve on Web Development?<br>
For me there are lots of room for improves especially in coding part and the tactics to properly arrange and design the website.
