function Alert(){
    if(document.getElementById('cbxPolicy2').checked == true){
      alert('You are now registered in CARE-VID website');
    }
    else{
      alert('Please check the "I accept terms and condition"');
     event.preventDefault();
    }
    
    }